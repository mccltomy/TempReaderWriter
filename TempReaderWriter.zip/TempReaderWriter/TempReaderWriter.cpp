#include <iostream>
#include <fstream>
#include <string>

using namespace std;

int main() {
    // Open input file for reading
    ifstream inFile("C:\\Users\\tommy\\OneDrive\\Desktop\\Temp_Files\\FahrenheitTemperature.txt");

    // Check if file was opened successfully
    if (!inFile.is_open()) {
        cerr << "Error opening input file." << endl;
        return 1;
    }

    // Open output file for writing
    ofstream outFile("C:\\Users\\tommy\\OneDrive\\Desktop\\Temp_Files\\CelsiusTemperature.txt");

    // Check if file was opened successfully
    if (!outFile.is_open()) {
        cerr << "Error opening output file." << endl;
        return 1;
    }

    // Read data from input file, convert to Celsius, and write to output file
    string city;
    int tempF;

    while (inFile >> city >> tempF) {
        double tempC = (tempF - 32) * 5.0 / 9.0;
        outFile << city << " " << tempC << endl;
    }

    // Close files
    inFile.close();
    outFile.close();

    return 0;
}
